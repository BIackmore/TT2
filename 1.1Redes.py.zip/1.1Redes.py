import os
import cv2
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models
import tkinter as tk
from tkinter import filedialog

TAMANO_IMAGEN = 128
DATASET_PATH = "/Users/mildredlagunes/Documents/ESCOM/8vo. semestre/TT2/1era. Parte/archive-4"

# CNN 


def crear_cnn():

    modelo = models.Sequential([
        layers.Conv2D(32,(3,3),input_shape=(TAMANO_IMAGEN,TAMANO_IMAGEN,3)),
        layers.LeakyReLU(alpha=0.1),
        layers.MaxPooling2D(),

        layers.Conv2D(64,(3,3)),
        layers.LeakyReLU(alpha=0.1),
        layers.MaxPooling2D(),

        layers.Conv2D(128,(3,3)),
        layers.LeakyReLU(alpha=0.1),
        layers.MaxPooling2D(),

        layers.Flatten(),
        layers.Dense(128),
        layers.LeakyReLU(alpha=0.1),

        # Clasificación binaria correcta
        layers.Dense(1, activation='sigmoid')
    ])

    modelo.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )

    modelo.summary()
    return modelo

cnn_filtro = crear_cnn()


# AUTOENCODER


def crear_autoencoder():

    input_img = layers.Input(shape=(TAMANO_IMAGEN,TAMANO_IMAGEN,3))

    # Encoder
    x = layers.Conv2D(64,(3,3),padding='same')(input_img)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.MaxPooling2D((2,2),padding='same')(x)

    x = layers.Conv2D(32,(3,3),padding='same')(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.MaxPooling2D((2,2),padding='same')(x)

    # Decoder
    x = layers.Conv2D(32,(3,3),padding='same')(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.UpSampling2D((2,2))(x)

    x = layers.Conv2D(64,(3,3),padding='same')(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.UpSampling2D((2,2))(x)

    decoded = layers.Conv2D(3,(3,3),activation='tanh',padding='same')(x)

    autoencoder = models.Model(input_img, decoded)

    autoencoder.compile(
        optimizer='adam',
        loss='mae'
    )

    autoencoder.summary()
    return autoencoder

autoencoder = crear_autoencoder()

# DATASET
def cargar_dataset():

    dataset = tf.keras.utils.image_dataset_from_directory(
        DATASET_PATH,
        image_size=(TAMANO_IMAGEN,TAMANO_IMAGEN),
        batch_size=32
    )

    #   ver clases
    print("Clases detectadas:", dataset.class_names)

    normalizacion = layers.Rescaling(1./127.5, offset=-1)
    dataset = dataset.map(lambda x,y:(normalizacion(x),y))

    return dataset


# ENTRENAMIENTO

def entrenar_cnn():
    dataset = cargar_dataset()
    cnn_filtro.fit(dataset, epochs=20)

def entrenar_autoencoder():
    dataset = cargar_dataset()
    dataset = dataset.map(lambda x,y:(x,x))
    autoencoder.fit(dataset, epochs=30)


# PREPROCESAMIENTO

def preprocesar_imagen(ruta):

    img = cv2.imread(ruta)
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)

    img = cv2.resize(img,(TAMANO_IMAGEN,TAMANO_IMAGEN))
    img = cv2.medianBlur(img,3)

    img = img.astype("float32")/127.5 - 1

    return img


# MOSTRAR IMAGEN

def mostrar_imagen(img,titulo):

    img = (img + 1) / 2
    plt.imshow(img)
    plt.title(titulo)
    plt.axis("off")
    plt.show()



def analizar_con_cnn(ruta):

    img_original = cv2.imread(ruta)
    img_original = cv2.cvtColor(img_original,cv2.COLOR_BGR2RGB)

    mostrar_imagen(img_original/255.0,"Imagen original")

  
    img = cv2.resize(img_original,(TAMANO_IMAGEN,TAMANO_IMAGEN))
    img = img/127.5 - 1
    entrada = np.expand_dims(img,axis=0)

    pred = cnn_filtro.predict(entrada)[0][0]

    print(f"Probabilidad de ser Sano: {pred}")

    if pred > 0.5:
        print("Clasificación CNN: Naturaleza")
    else:
        print("Clasificación CNN: Imagen fuera de contexto")

   
    img_pre = preprocesar_imagen(ruta)
    mostrar_imagen(img_pre,"Imagen preprocesada")

    entrada_pre = np.expand_dims(img_pre,axis=0)

    reconstruida = autoencoder.predict(entrada_pre)
    img_reconstruida = reconstruida[0]

    mostrar_imagen(img_reconstruida,"Imagen reconstruida")

   
    error = np.mean((entrada_pre - reconstruida)**2)
    print(f"Error de reconstrucción: {error}")

    
    if error < 0.01:
        print("Resultado final: SIN riesgo")
    else:
        print("Resultado final: POSIBLE riesgo")


# MENU


def menu():

    while True:

        print("\nMENU")
        print("1. Entrenar CNN")
        print("2. Entrenar Autoencoder")
        print("3. Cargar imagen del dispositivo")
        print("4. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            entrenar_cnn()

        elif opcion == "2":
            entrenar_autoencoder()

        elif opcion == "3":
            root = tk.Tk()
            root.withdraw()

            ruta = filedialog.askopenfilename(
                initialdir=os.path.expanduser("~/Desktop"),
                title="Seleccionar imagen",
                filetypes=[("Imagenes","*.jpg *.jpeg *.png")]
            )

            root.destroy()

            if ruta != "":
                analizar_con_cnn(ruta)

        elif opcion == "4":
            break

        else:
            print("Opción inválida")

menu()